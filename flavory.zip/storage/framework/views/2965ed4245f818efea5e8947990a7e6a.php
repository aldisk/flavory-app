<html>
    <head>
        <title><?php echo e($errmsg); ?></title>
    </head>
    <body>
        <h1><?php echo e($errmsg); ?></h1>
    </body>
</html><?php /**PATH C:\xampp\htdocs\flavory\resources\views/error.blade.php ENDPATH**/ ?>