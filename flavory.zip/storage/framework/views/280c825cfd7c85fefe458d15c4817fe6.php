<html>
    <head>
        <title>Resep Flavory</title>
    </head>
    <body>
        <h1>hanya dapat dilihat oleh user yang telah login</h1>
    </body>
</html><?php /**PATH C:\xampp\htdocs\flavory\resources\views/resep.blade.php ENDPATH**/ ?>