<html>
    <head>
        <title>Resep</title>
    </head>
    <body>
        <input type="hidden" value="<?php echo rand() ?>">
        <img src="1.jpg" alt="image">
    </body>
</html><?php /**PATH C:\xampp\htdocs\flavory\resources\views/view-resep-fix.blade.php ENDPATH**/ ?>