<html>
    <head>
        <title>demo</title>
    </head>
    <body>
        <img src="1.jpg" alt="">
    </body>
</html><?php /**PATH C:\xampp\htdocs\flavory\resources\views/image-test.blade.php ENDPATH**/ ?>