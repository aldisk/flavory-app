<html>
    <head>
    <title>Flavory</title>
    </head>
    <body>
        <form action="<?php echo e(route('searchResep')); ?>" method="get">
            
        </form>
        <?php if(isset($reseps)): ?>
        <ul>
            <?php $__currentLoopData = $reseps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($resep->nama); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <?php endif; ?>
    </body>
</html><?php /**PATH C:\xampp\htdocs\flavory\resources\views/show-search.blade.php ENDPATH**/ ?>