<html>
    <head>
        <title>Flavory - Update Profile</title>
    </head>
    <body>
        <h1>Update Profile</h1>
        <form action="<?php echo e(route('authUpdateProfile')); ?>", method="post">
            <?php echo csrf_field(); ?>
            <input type="text", name="oldpassword", placeholder="old password" required> <br>
            <input type="text", name="password", placeholder="new password" required> <br>
            <input type="text", name="fullname", value=<?php echo $profile->name; ?> required> <br>
            <input type="submit", value="Delete">
        </form>
    </body>
</html><?php /**PATH C:\xampp\htdocs\flavory\resources\views/update-profile.blade.php ENDPATH**/ ?>