<html>
    <head>
        <title>Flavory</title>
    </head>
    <body>
        <form action="<?php echo e(route('uploadPP')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <input type="file" name="pp" accept="image/png, image/jpeg, image/gif" >
            <input type="submit" value ="upload">
        </form>
    </body>
</html><?php /**PATH C:\xampp\htdocs\flavory\resources\views/profile-picture.blade.php ENDPATH**/ ?>