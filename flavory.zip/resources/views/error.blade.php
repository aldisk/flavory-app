<html>
    <head>
        <title>{{ $errmsg }}</title>
    </head>
    <body>
        <h1>{{ $errmsg }}</h1>
    </body>
</html>