
<html>
    <head>
        <title>Flavory - Home</title>
    </head>
    <body>
        <h1>About Me</h1>
        Name : {{ $profile->name }} <br>
        Username : {{ $profile->username }}
    </body>
</html>